package com.qa.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;

public class FlightBooking {
	WebDriver driver;

	@BeforeMethod
	public void launchingbrowser() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium Itishree\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		// Navigate to kayak site
		driver.get("https://www.kayak.ch/");
		Thread.sleep(1000);
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title, "Fl�ge, Hotels & Mietwagen finden | KAYAK");
	}

	/*
	 * TestScenario:User able to see the round trip flight Positive testcase1:Verify
	 * user able to see the round trip flight as per the input provided in
	 * https://www.kayak.ch/ inputs:From and To Destinations ,Date Range
	 */

	@Test
	public void flightbooking() throws InterruptedException {

		// Switch to Iframe
		driver.switchTo().frame("cmp-locator");
		System.out.println("********We are switch to the iframe*******");
		Thread.sleep(100);
		driver.switchTo().defaultContent();
		System.out.println("********We are on the main window*******");

		// Iframe Handling ---Accept Button
		driver.findElement(By.xpath(
				"//div[@class='Common-Gdpr-CookieConsentV2']/child::div[1]/div/div/div/div/div/div/div/div/div/div/button[contains(@id,'-accept')]"))
				.click();
		System.out.println("*********We are done***************");
		Thread.sleep(100);

		// Deleting the current location and sending Warsaw as From destination
		driver.findElement(By.xpath("//div[@class='vvTc-item-close']")).click();
		Thread.sleep(100);
		driver.findElement(By.xpath("//input[@placeholder='Von?']")).sendKeys("Warsaw");
		Thread.sleep(100);
		driver.findElement(By.xpath("//input[@placeholder='Von?']")).sendKeys(Keys.ENTER);
		Thread.sleep(100);

		// Clicking and sending Berlin as To destination
		driver.findElement(By.xpath(
				"//div[@class='zEiP-formField zEiP-destination']/div/div//div[@class='lNCO-icon lNCO-suffix-icon']"))
				.click();
		System.out.println("********clicked*******");
		driver.findElement(By.xpath("//input[@placeholder='Nach?']")).sendKeys("Prague");
		Thread.sleep(500);
		System.out.println("********Destination as Berlin*******");
		// driver.findElement(By.xpath("//input[@class='PVIO-input']")).click();

		// input[@type='checkbox' and @class='PVIO-input']
		driver.findElement(By.xpath("//input[@placeholder='Nach?']")).sendKeys(Keys.ENTER);
		Thread.sleep(100);

		// From date picker
		driver.findElement(By.xpath(
				"//*[@class='cQtq cQtq-mod-size-large cQtq-mod-radius-none cQtq-pres-default cQtq-mod-variant-modal']/div"))
				.click();
		Thread.sleep(100);
		String flag = "False";

		while (flag == "False") {

			if (driver.findElements(By.xpath("//div[text()='20'][contains(@aria-label,'20. Januar 2022')]"))
					.size() > 0) {

				driver.findElement(By.xpath("//div[text()='20'][contains(@aria-label,'20. Januar 2022')]")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//div[text()='20'][contains(@aria-label,'20. Januar 2022')]")).click();
				flag = "True";
				Thread.sleep(1000);
			}

			else {
				Thread.sleep(100);
				driver.findElement(By.xpath("//div[@class='Fj7W']/div[2]//span[@class='svg']")).click();
			}

			// To date picker
			driver.findElement(By.xpath(
					"//*[@class='cQtq cQtq-mod-size-large cQtq-mod-radius-none cQtq-pres-default cQtq-mod-variant-modal']/div[3]"))
					.click();
			Thread.sleep(100);
			String flag2 = "False";

			while (flag2 == "False") {

				if (driver.findElements(By.xpath("//div[text()='25'][contains(@aria-label,'25. Januar 2022')]"))
						.size() > 0) {

					driver.findElement(By.xpath("//div[text()='25'][contains(@aria-label,'25. Januar 2022')]")).click();
					flag2 = "True";
					Thread.sleep(100);
					// driver.findElement(By.xpath("//div[text()='25'][contains(@aria-label,'25.
					// Januar 2022')]")).click();
				}

				else {
					Thread.sleep(100);
					driver.findElement(By.xpath("//div[@class='Fj7W']/div[2]//span[@class='svg']")).click();
				}
				Thread.sleep(1000);
				// Click on search button
				driver.findElement(By.xpath("//*[local-name()='svg' and @class='c8LPF-icon']")).click();
				Thread.sleep(20000);

				// This will scroll down the page
				JavascriptExecutor js = (JavascriptExecutor) driver;
				WebElement price = driver.findElement(By.xpath("//div[text()='Zwischenstopp']"));
				js.executeScript("arguments[0].scrollIntoView();", price);
                Thread.sleep(200);
                
                //To change the Maximum price
				driver.findElement(By.xpath("//*[text()='Preis']")).click();
				System.out.println("clicked");
				WebElement slider = driver
						.findElement(By.xpath("//div[@class='handle right'][contains(@aria-label,'Maximalpreis')]"));

				Point location = slider.getLocation();
				int x = location.getX();
				int y = location.getY();
				System.out.println("Coordinates of an element is : " + x + " and " + y);
				Actions action = new Actions(driver);
				action.dragAndDropBy(slider, -60, 0).build().perform();
				Thread.sleep(1500);

			}

		}
	}

	@AfterMethod
	public void tearDown() {
		driver.close();
	}
}